
const PORT = process.env.PORT || 5000;
//exports.base_url = "http://localhost:"+PORT+"/";
exports.base_url = "https://revolfoods.herokuapp.com/";
exports.customer_image_url = "assets/customer_images/";
exports.customer_image_thumbnail_url = "assets/customer_images/thumbnails/";

exports.product_image_url = "assets/product_images/";
exports.product_image_thumbnail_url = "assets/product_images/thumbnails/";